package com.dynamic.dialog.Resource;

public class PhpLinks {

    //Server Ip Address

    public final String SERVER_IP_ADDRESS = "http://24locator.com/MultipleDialog/";

    public final String COUNTRY_URL = "http://ip-api.com/json";
    public final String DIALOG_URL = SERVER_IP_ADDRESS + "getDialogOffer.php";
    public final String MEDIUMBANNER_URL = SERVER_IP_ADDRESS + "getMediumBanner.php";
    public final String SMALLBANNER_URL = SERVER_IP_ADDRESS + "getSmallBanner.php";
}
